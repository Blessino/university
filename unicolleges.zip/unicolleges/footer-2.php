    <!-- script -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.4/jquery.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.2.2/js/swiper.min.js'></script>
    <script src="assets/js/jquery.magnific-popup.js"></script>
    <script src="assets/js/script.js"></script>

</body>
</html>